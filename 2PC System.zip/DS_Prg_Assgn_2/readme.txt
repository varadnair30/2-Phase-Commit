
EXECUTION PROCEDURE:

This project is implemented using python.

Step 1: Begin by installing latest Python.

Step 2: Open the terminal and navigate to the designated path where your source code resides.

Step 3: If the config.txt file is present, remove it.

Step 4: Initiate nodes by executing python node_instance.py. You can start as many nodes as required.

Step 5: Once the nodes are active and listening on their respective ports, launch the coordinator using the command python coordinator_instance.py <test-scenario>.

Step 6: Upon coordinator execution with a test case scenario number, the following scenarios are activated based on the command line test-scenario input:

1: "Failure before commit message"
2: "Failure after commit message"
3: "TC Failure"
4: "Success"
5: "exit"

Step 7: Upon selecting a specific operation for testing, receive the corresponding response. As operations are executed, logs are generated in the backend for both coordinator and nodes.

Step 8: After each operation, the transaction status (committed or aborted) is updated in the logs.

Step 9: In the participants' terminals, observe the display of the HTTP status message "HTTP 200," indicating the successful completion of a particular transaction.