import random
import sys
import threading

class Coordinator:
    def __init__(self, log_name):
        self.node_connections = []
        self.lock = threading.Lock()
        self.transaction_id = 0
        self.is_recovery_mode = 0

        try:
            self.log_file = open(log_name + "_custom.log", "a+")
        except Exception as ex:
            print(ex)
            sys.exit()

    is_successful = False

    def write_to_log(self, message):
        self.log_file.write(message)

    def is_recovery_needed(self):
        lastLog = ""

        for line in self.log_file:
            lastLog = line

        params = lastLog.split(" ")
        print(params)

        if str(params[-1]) == "Commit\n" or str(params[-1]) == "Abort\n":
            print("No need for recovery")
            return True

        self.is_recovery_mode = 1
        self.lock.acquire()
        if params[1] == "put":
            print(f" Recovering {params[1]} operation")
            self.commit_action()
            self.write_to_log(" " + "Commit\n")
        elif params[1] == "get":
            print(f" Recovering {params[1]} operation")
            self.retrieve(params[2])
        elif params[1] == "del":
            print("Recovering delete function")
            self.remove(params[2])
        self.log_file.close()
        self.lock.release()
        self.is_recovery_mode = 0

    def insert_data(self, key, value):
        self.write_to_log("\nCoordinator prepare: Inserting data\n")
        print("Coordinator status: Inserting data")

        self.lock.acquire()
        for connection in self.node_connections:
            self.write_to_log("Node Status: " + connection._ServerProxy__host)
            print("Node Status: " + connection._ServerProxy__host, end="")
            try:
                is_successful = connection.insert_into_database(key, value)
                self.write_to_log(", Returned status: " + str(is_successful) + "\n")
                print(", Returned status: " + str(is_successful))
            except Exception as exp:
                print(exp.args)
            if not is_successful:
                self.cancel_action()
                self.write_to_log(" " + "Cancel\n")
                return False
        if int(key) != 2:
            if int(key) != 3:
                self.commit_action()
                self.write_to_log("Commit\n\n")
            else:
                self.write_to_log(
                    "TC not responded after prepare phase, nodes blocked\n\n"
                )
                print("TC not responding after prepare phase, nodes blocked")
                for connection in self.node_connections:
                    connection.cancel_action()
        else:
            print("Nodes not responding")
            self.cancel_action()
            self.write_to_log(" " + "Cancel\n\n")
        self.log_file.close()
        self.lock.release()

    def retrieve(self, key):
        print("Lead retrieve")
        self.write_to_log(" get " + key)

        random_index = random.randrange(0, len(self.node_connections), 1)
        retrieved_value = self.node_connections[random_index].retrieve(key)
        print("Retrieved value: %s" % retrieved_value)

        self.write_to_log(" Commit\n")
        self.commit_action()

    def remove(self, key):
        self.write_to_log("\nCoordinator prepare: Deleting data\n")
        print("Coordinator status: Deleting data")

        self.lock.acquire()
        for connection in self.node_connections:
            self.write_to_log("Node Status: " + connection._ServerProxy__host)
            print("Node Status: " + connection._ServerProxy__host, end="")
            is_successful = False
            try:
                is_successful = connection.remove(key)
                self.write_to_log(", Returned status: " + str(is_successful) + "\n")
                print(", Returned status: " + str(is_successful))
            except Exception as exp:
                print(exp.args)
            if not is_successful:
                self.cancel_action()
                self.write_to_log(" " + "Cancel\n")
                return False
        self.commit_action()
        self.write_to_log(" " + "Commit\n")
        self.log_file.close()
        self.lock.release()

    def resolve(self, key):
        is_successful = False
        for connection in self.node_connections:
            is_successful ^= connection.resolve(key)
        return is_successful

    def commit_action(self):
        print("Make All Nodes Commit - ", end="")
        for connection in self.node_connections:
            connection.commit_action()
        print("Done\n")

    def cancel_action(self):
        print("Make All Nodes Cancel")
        for connection in self.node_connections:
            connection.cancel_action()
        print("Done\n")
1