import sqlite3 as lite
import sys


class Node:
    def __init__(self, name, port):
        self.recovery_flag = None
        self.name = name
        self.port = port

        try:
            self.log_file = open(name + "_custom.log", "a+")
            self.connection = lite.connect(self.name + "_custom.db")
            self.cur = self.connection.cursor()
            self.cur.execute(
                "CREATE TABLE IF NOT EXISTS Info(key INT PRIMARY KEY, value TEXT)"
            )
            self.connection.commit()
        except Exception as exp:
            print(f"Error: {exp}")
            sys.exit()

    def write_to_log(self, message):
        self.log_file.write(message)

    def recovery_need(self):
        lastLog = ""
        for line in self.log_file:
            lastLog = line
        params = lastLog.split(" ")
        if str(params[-1]) in ["Commit\n", "Abort\n"]:
            self.write_to_log(" No need for recovery")
            return True
        if params[1] == "put":
            self.write_to_log(f" Recovering {params[1]} operation")
        elif params[1] == "get":
            self.write_to_log(f" Recovering {params[1]} operation")
            self.cur.execute("SELECT value FROM Info WHERE KEY = ?", params[2])
        elif params[1] == "del":
            self.write_to_log(" Recovering delete operation")
            self.cur.execute("DELETE FROM Info WHERE KEY = ?", params[2])

        self.connection.commit()
        self.write_to_log(" Commit\n")
        self.log_file.flush()
        self.recovery_flag = 0
        return 1

    def fetch_from_database(self, key):
        result = ""
        self.write_to_log(" get " + key)
        self.log_file.flush()
        try:
            self.cur.execute("SELECT value FROM Info WHERE key = ?", key)
            result = self.cur.fetchone()
        except Exception as exp:
            print(exp)
        return str(result)

    def insert_into_database(self, key, value):
        decision_flag = self.make_decision(key)
        if int(key) != 1:
            self.write_to_log(f" Insert key: {key}, value: {value} ")
            if decision_flag and int(key) != 2:
                try:
                    self.cur.execute(
                        "INSERT OR REPLACE INTO Info VALUES(?,?)", (key, value)
                    )
                except Exception as exp:
                    print(exp)
                return True
            else:
                self.recovery_flag = 1
                return True
        else:
            return False

    def delete(self, key):
        decision_flag = self.make_decision(key)
        if int(key) != 1:
            self.write_to_log(f" delete {key}")
            self.log_file.flush()
            if decision_flag and int(key) != 2:
                try:
                    self.cur.execute("DELETE FROM Info WHERE key = ?", key)
                except Exception as exp:
                    print(exp)
                return True
            else:
                return False
        else:
            return False

    @staticmethod
    def make_decision(key):
        if int(key) == 1:
            return False
        elif int(key) == 2:
            return True
        else:
            return True

    def commit_action(self):
        try:
            self.connection.commit()
            self.write_to_log(" - Commit successful\n")
        except Exception as exp:
            print(exp)
            self.write_to_log(" - Commit failed")
            return False

        self.log_file.flush()
        return True

    def cancel_action(self):
        self.write_to_log(" - Abort\n")
        self.log_file.flush()
        return True
